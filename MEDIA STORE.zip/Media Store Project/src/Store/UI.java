package Store;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import Users.*;
import static java.lang.System.in;


public class UI {
    private ArrayList<String> users = new ArrayList<String>();
    private User userLoggedIn;
    private final BufferedReader input = new BufferedReader(new InputStreamReader(in));

    public void initialize() throws IOException, InterruptedException {
        readEmployeesFromFile();
        while (true) {
            System.out.println("Username: ");
            String uname = input.readLine();
            System.out.println("Password: ");
            String pass = input.readLine();
            clearScreen();
            if (login(uname, pass)){
                break;
            }
            else{
                System.out.println("Wrong password or Username");
                Thread.sleep(1000);
            }
        }

        userLoggedIn.initialize();
        userLoggedIn.actShow();
        userLoggedIn.act(); // Call act method with a value
    }
    private boolean login(String username, String password) throws InterruptedException {
        for(String user : users){
            String[] data = user.split(":");
            if(data[0].equals(username) && data[1].equals(password)){
                switch (data[2].toLowerCase()){
                    case "manager":
                        userLoggedIn = new Manager();
                        break;
                    case "cashier":
                        userLoggedIn = new Cashier();
                        break;
                    case "steward":
                        userLoggedIn = new Steward();
                        break;
                    case "customer":
                        userLoggedIn = new Customer();
                        break;
                    default:
                        System.out.println("CORRUPTED DATA FILE!");
                        Thread.sleep(10000);
                        return false;
                }
                userLoggedIn.setUserID(username);
                return true;
            }
        }
        return false;
    }
    private void readEmployeesFromFile() throws FileNotFoundException {
        Scanner scanner;
        String filename ="users.txt";
        scanner = new Scanner(new File("src/data/" + filename));
        String line;
        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            users.add(line);
        }
    }
    private static void clearScreen() {
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
}
