package Store;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import Items.*;

public class MediaStore {
    private final Map<String, Item> items = new HashMap();

    public void addItem(Item item){
        if(items.containsKey(item.getBarcode())){
            items.get(item.getBarcode()).increaseQuantity(item.getQuantity());
        }
        else {
            item.setBarcode(generateBarcode(item.getTitle(),item.getType()));
            items.put(item.getBarcode(), item);
        }
        writeItemsToFile();
    }
    public void locateItem(String barcode){
        if(items.containsKey(barcode)){
            System.out.println(items.get(barcode).getShelf());
        }
        else{
            System.out.println("Item not found");
        }
    }
    public void displayDetails(String barcode){
        if(this.items.containsKey(barcode)){
            this.items.get(barcode).displayDetails();
        }
        else{
            System.out.println("Item not found");
        }
    }
    public void buy(String barcode, String userid){
        if(this.items.containsKey(barcode)){
            this.items.get(barcode).decreaseQuantity();
            System.out.println("You paid " + getItems().get(barcode).getPrice() + "$ to buy " + getItems().get(barcode).getTitle());
        }
        else{
            System.out.println("Item not found but you have reserved the item!");
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/data/reservations.txt", true))) {
                writer.write("\n"+barcode + " " + userid);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        writeItemsToFile();
    }

    public void sellItem(String barcode){
        if(items.containsKey(barcode)){
            if(items.get(barcode).getQuantity() > 0){
                items.get(barcode).decreaseQuantity();
                System.out.println("Item sold ->" +items.get(barcode).getTitle());
            }
            else {
                System.out.println("There is no " +items.get(barcode).getTitle()+" left");
            }
        }
        else {
            System.out.println("There is no product associated with the barcode: " +barcode);
        }
        writeItemsToFile();
    }
    public void inventoryCheck(String barcode){
        if(items.containsKey(barcode)){
            System.out.println("We have "+ items.get(barcode).getTitle()+ " with the amount of " +items.get(barcode).getQuantity());

        }
        else {
            System.out.println("This item is not in the inventory-> "+barcode);
        }
    }
    public void readItemsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("src/data/Items.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                switch (parts[0].toLowerCase()) {
                    case "book":
                        Book book = new Book(parts[2], parts[3], Integer.parseInt(parts[5]), parts[1], Double.parseDouble(parts[4]), parts[6]);
                        items.put(generateBarcode(parts[1],"book"), book);
                        break;
                    case "dvd":
                        DVD dvd = new DVD(parts[2], parts[3], Integer.parseInt(parts[5]), parts[1], Double.parseDouble(parts[4]), parts[6]);
                        items.put(generateBarcode(parts[1],"dvd"), dvd);
                        break;
                    case "magazine":
                        Magazine magazine = new Magazine(parts[2], parts[3], Integer.parseInt(parts[5]), parts[1], Double.parseDouble(parts[4]), parts[6]);
                        items.put(generateBarcode(parts[1],"magazine"), magazine);
                        break;
                    case "newspaper":
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Date date = dateFormat.parse(parts[3]);
                        NewsPaper np = new NewsPaper(parts[2], date, Integer.parseInt(parts[5]), parts[1], Double.parseDouble(parts[4]), parts[6]);
                        items.put(generateBarcode(parts[1],"newspaper"), np);
                        break;
                    // Add similar blocks for any other item types
                }

            }
            checkReservations();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
    public void writeItemsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/data/Items.txt"))) {
            for (Item item : items.values()) {
                writer.write(item.getFileData() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void checkReservations(){
        try (BufferedReader reader = new BufferedReader(new FileReader("src/data/reservations.txt"))){
            ArrayList<String> reservations = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if(items.containsKey(parts[0])){
                    items.get(parts[0]).decreaseQuantity();
                    System.out.println(items.get(parts[0]).getTitle() + " Reservation fulfilled");
                }else{
                    reservations.add(line);
                }
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/data/reservations.txt"))) {
                for(int i = 0; i< reservations.size(); i++){
                    writer.write(reservations.get(i));
                    if(i != reservations.size()-1){
                        writer.write("\n");
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
    private String generateBarcode(String title, String type) {
        try {
            String input = title + type;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating barcode", e);
        }
    }
    public Map<String, Item> getItems(){
        return items;
    }
}
