package Users;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;

import static java.lang.System.in;

public class Customer extends User{
    public void reservation(String barcode){

    }

    @Override
    public void act() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String str = reader.readLine();
        String input = "";
        if (!Objects.equals(str, "2")){
            input = this.getInput();
        }

            switch(str){
                case "1":
                    buy(input);
                    break;
                case "2":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid input");
                    act();
            }

        this.actShow();
        this.act();
    }

    @Override
    public void actShow() {
        int i = 0;
        System.out.println(++i + "- Buy a Product");
        System.out.println(++i + "- LogOut");
    }
    public void buy(String barcode){
        getMediaStore().buy(barcode, this.getUserID());
    }
}
