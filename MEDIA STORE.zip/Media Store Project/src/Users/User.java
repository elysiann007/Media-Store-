package Users;
import Store.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import static java.lang.System.in;

public class User implements UserInterface{
    private String name;
    private int password;
    private String UserID;
    private MediaStore mediaStore;

    public String getName() {
        return this.name;
    }
    public String getUserID(){
        return this.UserID;
    }
    public void setUserID(String username){
        this.UserID = username;
    }
    public MediaStore getMediaStore() {
        return this.mediaStore;
    }
    public void act() throws IOException {}
    public String getInput() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        System.out.println("Enter the information. Whether in the format of [Title Type] or [Barcode]");
        String input = reader.readLine();
        if (input.contains(" ")) {
            int lastSpaceIndex = input.lastIndexOf(" ");
            String firstPart = input.substring(0, lastSpaceIndex);
            String secondPart = input.substring(lastSpaceIndex + 1);
            return generateBarcode(firstPart, secondPart);

        } else {
            for (int i = 0; i < input.length(); i++) {
                if (input.charAt(i) != '0' &&  input.charAt(i) != '1'){
                    System.out.println("Invalid input!");
                    return "";
                }
            }
            return input;
        }
    }
    public void initialize(){
        this.mediaStore = new MediaStore();
        this.mediaStore.readItemsFromFile();
    }
    public void actShow(){}
    public String generateBarcode(String title, String type) {
        try {
            String input = title + type;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating barcode", e);
        }
    }
}
