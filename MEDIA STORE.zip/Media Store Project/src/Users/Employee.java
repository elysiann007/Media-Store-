package Users;
public class Employee extends User{
    String position;

    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public void search(String barcode){
        this.getMediaStore().inventoryCheck(barcode);
    }
    public void locate(String barcode){
        this.getMediaStore().locateItem(barcode);
    }
    public void detail(String barcode){
        this.getMediaStore().displayDetails(barcode);
    }
    public void sell(String barcode){
        this.getMediaStore().sellItem(barcode);
    }

}
