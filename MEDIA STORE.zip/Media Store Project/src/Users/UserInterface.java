package Users;

import java.io.IOException;

public interface UserInterface {
    void act() throws IOException;
    void actShow();
}
