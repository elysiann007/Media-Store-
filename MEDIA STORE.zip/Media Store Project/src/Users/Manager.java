package Users;

import Items.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import static java.lang.System.in;

public class Manager extends Employee implements UserInterface{
    public void updateCatalogue() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        System.out.println("Enter Type: ");
        String type = reader.readLine().toLowerCase();
        if(!type.equals("book") && !type.equals("dvd") && !type.equals("magazine") && !type.equals("newspaper")){
            System.out.println("Invalid type");
            return;
        }
        System.out.println("Enter Title: ");
        String title = reader.readLine().toLowerCase();
        System.out.println("Enter Amount: ");
        String amountString = reader.readLine().toLowerCase();
        int amount = 0;
        try {
            amount = Integer.parseInt(amountString);
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount.");
            return;
        }
        if(this.getMediaStore().getItems().containsKey(generateBarcode(title,type))){
            this.getMediaStore().getItems().get(generateBarcode(title,type)).increaseQuantity(amount);
            System.out.println("There was already an item with the same barcode. Quantity has increased");
        }
        else{
            System.out.println("Enter Price (123.45): ");
            double price = 0.0;
            String priceString = reader.readLine().toLowerCase();
            try {
                price = Double.parseDouble(priceString);
            } catch (NumberFormatException e) {
                System.out.println("Invalid price format.");
                return;
            }
            System.out.println("Enter Shelf: ");
            String shelf = reader.readLine().toLowerCase();
            switch (type){
                case "book":
                    System.out.println("Enter Author: ");
                    String author = reader.readLine().toLowerCase();
                    System.out.println("Enter Publisher: ");
                    String publisher = reader.readLine().toLowerCase();
                    Item book = new Book( author,  publisher,  amount,  title,  price,  shelf);
                    this.getMediaStore().addItem(book);
                    break;
                case "dvd":
                    System.out.println("Enter director: ");
                    String director = reader.readLine().toLowerCase();
                    System.out.println("Enter genre: ");
                    String genre = reader.readLine().toLowerCase();
                    Item dvd = new DVD(director,  genre,  amount,  title,  price,  shelf);
                    this.getMediaStore().addItem(dvd);
                    break;
                case "magazine":
                    System.out.println("Enter issue: ");
                    String issue = reader.readLine().toLowerCase();
                    System.out.println("Enter editor: ");
                    String editor = reader.readLine().toLowerCase();
                    Item magazine = new Magazine(issue,  editor,  amount,  title,  price,  shelf);
                    this.getMediaStore().addItem(magazine);
                    break;
                case "newspaper":
                    System.out.println("Enter edition: ");
                    String edition = reader.readLine().toLowerCase();
                    System.out.println("Enter date (dd-MM-yyyy): ");
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                    Date date = null;
                    String dateString = reader.readLine().toLowerCase();

                try {
                    date = dateFormat.parse(dateString);
                } catch (ParseException e) {
                    System.out.println("Invalid date format. Please enter the date in the format dd-MM-yyyy.");
                    return;
                }
                    Item newspaper = new NewsPaper(edition,  date,  amount,  title,  price,  shelf);
                    this.getMediaStore().addItem(newspaper);
                break;
            }
            System.out.println("Item has been added to the catalog.");
            this.getMediaStore().writeItemsToFile();
        }
    }

    @Override
    public void act() throws IOException {


        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String str = reader.readLine();
        String input = "";
        if (!Objects.equals(str, "5") && !Objects.equals(str, "6")){
            input = this.getInput();
        }

            switch(str){
                case "1":
                    sell(input);
                    break;
                case "2":
                    search(input);
                    break;
                case "3":
                    locate(input);
                    break;
                case "4":
                    detail(input);
                    break;
                case "5":
                    updateCatalogue();
                    break;
                case "6":
                    System.exit(0);
                default:
                    System.out.println("Invalid input.");
                    act();
            }
        this.actShow();
        this.act();

    }

    @Override
    public void actShow() {
        int i = 0;
        System.out.println(++i + "- Sell a Product");
        System.out.println(++i + "- Search a Product");
        System.out.println(++i + "- Locate a Product");
        System.out.println(++i + "- Detail a Product");
        System.out.println(++i + "- Update a Product");

        System.out.println(++i + "- LogOut");
        System.out.print("-> ");
    }
}
