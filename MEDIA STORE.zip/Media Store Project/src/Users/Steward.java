package Users;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;

import static java.lang.System.in;

public class Steward extends Employee{



    @Override
    public void act() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String str = reader.readLine();
        String input = "";
        if (!Objects.equals(str, "4")){
            input = this.getInput();
        }

            switch(str){
                case "1":
                    search(input);
                    break;
                case "2":
                    locate(input);
                    break;
                case "3":
                    detail(input);
                    break;
                case "4":
                    System.exit(0);
                default:
                    System.out.println("Invalid input");
                    act();
            }
        this.actShow();
        this.act();

    }

    @Override
    public void actShow() {
        int i =0;
        System.out.println(++i + "- Search a Product");
        System.out.println(++i + "- Locate a Product");
        System.out.println(++i + "- Detail a Product");

        System.out.println(++i + "- LogOut");
    }
}
