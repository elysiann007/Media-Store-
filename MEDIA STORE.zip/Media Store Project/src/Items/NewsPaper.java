package Items;
import java.text.SimpleDateFormat;
import java.util.Date;
public class NewsPaper extends Item implements ItemInterface {
    private String edition;
    private Date date;
    public NewsPaper(String edition, Date date, int amount, String title,  double price, String shelf) {
        this.setQuantity(amount);
        this.setTitle(title);
        this.setPrice(price);
        this.setBarcode(generateBarcode(title,"newspaper"));
        this.setEdition(edition);
        this.setDate(date);
        this.setShelf(shelf);
        this.setType("newspaper");
    }
    @Override
    public String getFileData() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = dateFormat.format(getDate());
        return getType()+","+getTitle()+","+getEdition()+","+formattedDate+","+getPrice()+","+getQuantity()+","+getShelf();
    }
    @Override
    public void displayDetails() {
        System.out.println("Type: " + this.getType());
        System.out.println("Title: " + this.getTitle());
        System.out.println("Edition: " + this.getEdition());
        System.out.println("Date: " + this.getDate());
        System.out.println("Barcode: " + this.getBarcode());
        System.out.println("Price: " + this.getPrice());
    }
    public Date getDate() {
        return date;
    }

    public String getEdition() {
        return edition;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }
}
