package Items;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class Item implements ItemInterface {
    private String barcode;
    private double price;
    private int quantity;
    private String type;
    private String title;
    private String shelf;
    public String getShelf(){
        return this.shelf;
    };
    public void setShelf(String shelf) {
        this.shelf = shelf;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public void increaseQuantity(int amount) {
        this.quantity = quantity+amount;
    }
    public void decreaseQuantity() {
        this.quantity = quantity-1;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getTitle() {
        return this.title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getBarcode() {
        return barcode;
    }
    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
    public String generateBarcode(String title, String type) {
        try {
            String input = title + type;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating barcode", e);
        }
    }
    public int getAmount(){
        return this.quantity;
    }
    @Override
    public String getFileData() {
        return "";
    }

    @Override
    public void displayDetails() {

    }
}
