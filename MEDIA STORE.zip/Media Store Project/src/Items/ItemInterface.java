package Items;

public interface ItemInterface {
    String getFileData();
    void displayDetails();
}
