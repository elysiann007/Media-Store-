package Items;
public class Magazine extends Item implements ItemInterface {
    private String issue;
    private String editor;
    public Magazine(String issue, String editor, int amount, String title, double price, String shelf) {
        this.setQuantity(amount);
        this.setIssue(issue);
        this.setEditor(editor);
        this.setTitle(title);
        this.setPrice(price);
        this.setBarcode(generateBarcode(title,"magazine"));
        this.setShelf(shelf);
        this.setType("magazine");
    }
    @Override
    public String getFileData() {
        return getType()+","+getTitle()+","+getIssue()+","+getEditor()+","+getPrice()+","+getQuantity()+","+getShelf();
    }

    @Override
    public void displayDetails() {
        System.out.println("Type: " + this.getType());
        System.out.println("Title: " + this.getTitle());
        System.out.println("Issue: " + this.getIssue());
        System.out.println("Editor: " + this.getEditor());
        System.out.println("Barcode: " + this.getBarcode());
        System.out.println("Price: " + this.getPrice());
    }

    public String getEditor() {
        return editor;
    }
    public String getIssue() {
        return issue;
    }
    public void setEditor(String editor) {
        this.editor = editor;
    }
    public void setIssue(String issue) {
        this.issue = issue;
    }
}
