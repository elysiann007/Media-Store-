package Items;

public class DVD extends Item implements ItemInterface {
    private String director;
    private String genre;
    public DVD(String director, String genre, int amount, String title, double price, String shelf) {
        this.setQuantity(amount);
        this.setTitle(title);
        this.setPrice(price);
        this.setBarcode(generateBarcode(title,"dvd"));
        this.setDirector(director);
        this.setGenre(genre);
        this.setShelf(shelf);
        this.setType("dvd");
    }
    @Override
    public String getFileData() {
        return getType()+","+getTitle()+","+getDirector()+","+getGenre()+","+getPrice()+","+getQuantity()+","+getShelf();
    }
    @Override
    public void displayDetails() {
        System.out.println("Type: " + this.getType());
        System.out.println("Title: " + this.getTitle());
        System.out.println("Director: " + this.getDirector());
        System.out.println("Genre: " + this.getGenre());
        System.out.println("Barcode: " + this.getBarcode());
        System.out.println("Price: " + this.getPrice());
    }
    public String getDirector() {
        return director;
    }
    public void setDirector(String director) {
        this.director = director;
    }
    public String getGenre() {
        return genre;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
}
