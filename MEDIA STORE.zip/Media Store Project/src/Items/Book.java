package Items;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class Book extends Item implements ItemInterface {
    private String author;
    private String publisher;
    public Book(String author, String publisher, int amount, String title, double price, String shelf) {
        this.setQuantity(amount);
        this.setAuthor(author);
        this.setPublisher(publisher);
        this.setTitle(title);
        this.setPrice(price);
        this.setBarcode(generateBarcode(getTitle(),getType()));
        this.setShelf(shelf);
        this.setType("book");
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getPublisher() {
        return publisher;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }


    @Override
    public String getFileData() {
        return getType()+","+getTitle()+","+getAuthor()+","+getPublisher()+","+getPrice()+","+getQuantity()+","+getShelf();
    }
    @Override
    public void displayDetails() {
        System.out.println("Type: " + this.getType());
        System.out.println("Title: " + this.getTitle());
        System.out.println("Author: " + this.getAuthor());
        System.out.println("Publisher: " + this.getPublisher());
        System.out.println("Barcode: " + this.getBarcode());
        System.out.println("Price: " + this.getPrice());
    }

}
